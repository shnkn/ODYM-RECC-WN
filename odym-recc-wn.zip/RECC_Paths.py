import os 

current_path = os.path.abspath(os.getcwd())

odym_path         = os.path.join(current_path,'odym')
data_path         = os.path.join(current_path,'Dataset')
results_path      = os.path.join(current_path,'results')
